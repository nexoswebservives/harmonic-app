import flet as ft
import os

def main(page: ft.Page):
    def route_change(e):
        page.views.clear()
        if page.route == "/":
            page.views.append(
                ft.View("/", controls=[
                    ft.Text("✅ Projeto Flet Web no Render funcionando perfeitamente!", size=24)
                ])
            )
        page.update()

    page.window.manifest = "/web/manifest.json"
    page.window.register_service_worker("/web/service-worker.js")
    page.window.favicon = "/web/icons/icon-192.png"

    page.on_route_change = route_change
    route_change(None)

if __name__ == "__main__":
    ft.app(target=main, port=int(os.getenv("PORT", 8000)), view=ft.WEB_BROWSER)
