Projeto Harmonic App PWA - Estrutura base para testes.
